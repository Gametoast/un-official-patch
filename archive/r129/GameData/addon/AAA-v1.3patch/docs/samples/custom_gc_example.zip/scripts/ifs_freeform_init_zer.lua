-- initialize for Zer War
print("ifs_freeform_init_zer.lua")
ifs_freeform_init_zer = function(this, ALL, IMP)
	print("ifs_freeform_init_zer: ifs_freeform_init_zer()")

	-- common init
	ifs_freeform_init_common(this)

	--replacing this table from init_common, by [RDH]Zerted
	-- per-planet camera offsets
	this.cameraOffset = {
		["end"] = { 0, 1, 1 },
		["hot"] = { 0, 1, 1 },
		["tat"] = { 0, 1, 1 },
	}

	-- default victory condition (take all planets)
	this:SetVictoryPlanetLimit(nil)
	
	-- associate codes with teams
	this.teamCode = {
		[ALL] = "all",
		[IMP] = "imp"
	}
	
	-- use Zer setup
	this.Setup = function(this)
		print("ifs_freeform_init_zer: ifs_freeform_init_zer(): Setup()")
	

		-- remove unused planets
		print("ifs_freeform_init_zer: ifs_freeform_init_zer(): Setup(): Removing unused planets")
		DeleteEntity("kam")
		DeleteEntity("kam_system")
		DeleteEntity("geo_system")
		DeleteEntity("end_star")
		DeleteEntity("hot_star")
		DeleteEntity("tantive")
		
DeleteEntity("cor")
DeleteEntity("dag")
DeleteEntity("fel")
DeleteEntity("kam_star")
DeleteEntity("mus")
DeleteEntity("kas")
DeleteEntity("nab")
DeleteEntity("myg")
DeleteEntity("pol")
DeleteEntity("uta")
DeleteEntity("yav")
DeleteEntity("star04")
DeleteEntity("star05")
DeleteEntity("star06")
DeleteEntity("star07")
DeleteEntity("star08")
DeleteEntity("star09")
DeleteEntity("star10")
DeleteEntity("star11")
DeleteEntity("star12")
DeleteEntity("star13")
DeleteEntity("star14")
DeleteEntity("star15")
DeleteEntity("star16")
DeleteEntity("star17")
DeleteEntity("star18")
DeleteEntity("star19")
DeleteEntity("star20")
					
		-- create the connectivity graph
		this.planetDestination = {
			["end"] = { "star02", "star01" },
			["hot"] = { "star01" },
			["tat"] = { "star02", "star01" },
			["star01"] = { "end", "tat", "hot" },
			["star02"] = { "end", "tat" },
		}

		-- resource value for each planet
		this.planetValue = {
			["end"] = { victory = 40, defeat = 9, turn = 3 },
			["hot"] = { victory = 100, defeat = 30, turn = 5 },
			["tat"] = { victory = 40, defeat = 9, turn = 3 },
		}
		
		this.spaceValue = {
			victory = 50, defeat = 20,
		}
		
		-- mission to launch for each planet
		this.spaceMission = {
			["con"] = { "spa1g_ass", "spa8g_ass", "spa9g_ass" }
		}
		this.planetMission = {
			["end"] = {
				["con"] = "end1g_con",
				["hunt"] = "end1g_hunt",
			},
			["hot"] = {
				["con"] = "hot1g_con",
				["hunt"] = "hot1g_hunt",
			},
			["tat"] = {
				["con"] = "tat2g_con",
				["hunt"] = "tat2g_hunt",
			},
		}
		
		-- associate names with teams
		this.teamName = {
			[0] = "",
			[ALL] = "common.sides.all.name",
			[IMP] = "common.sides.imp.name"
		}
		
		-- associate names with team bases
		this.baseName = {
			[ALL] = "ifs.freeform.base.all",
			[IMP] = "ifs.freeform.base.imp"
		}
		
		-- associate names with team fleets
		this.fleetName = {
			[0] = "",
			[ALL] = "ifs.freeform.fleet.all",
			[IMP] = "ifs.freeform.fleet.imp"
		}
		
		-- associate entity class with team fleets
		this.fleetClass = {
			[ALL] = "gal_prp_moncalamaricruiser",
			[IMP] = "gal_prp_stardestroyer"
		}
		
		-- associate icon textures with team fleets
		this.fleetIcon = {
			[ALL] = "all_fleet_normal_icon",
			[IMP] = "imp_fleet_normal_icon"
		}
		this.fleetStroke = {
			[ALL] = "all_fleet_normal_stroke",
			[IMP] = "imp_fleet_normal_stroke"
		}
		
		-- set the explosion effect for each team
		this.fleetExplosion = {
			[ALL] = "gal_sfx_moncalamaricruiser_exp",
			[IMP] = "gal_sfx_stardestroyer_exp"
		}
		
		-- team base planets
		this.planetBase = {
			[ALL] = "tat",
			[IMP] = "end"
		}
		
		-- team potential starting locations
		this.planetStart = {
			[ALL] = { "tat" },
			[IMP] = { "end" },
		}

		print("ifs_freeform_init_zer: ifs_freeform_init_zer(): Setup(): Finished")
	end
end
