--This is the main setup script for a custom Galactic Conquest
print("custom_gc_1: Entered")

-------------------------------------------------------------------------------
-- Those 7 steps are in this section
-------------------------------------------------------------------------------
--Modders, for basic custom Galactic Conquest support
--	you only need to change the variables in this section.
--  If you want to do advanced things, you will need to 
--		learn how the real game does it.
--	If you need to change something else in the game, it is
--		best to 'take control' of the function as done
--		a few times below this section.  This allows you to
--		change parts of the shell without replacing shell.lvl.

--To use this script in your own custom Galactic Conquest,
-- 1) you need to search/replace: cgc1/cgc#
-- 2) you need to search/replace: gc_1/cg_#
--	where '#' is the number of this custom Galactic Conquest

-- 3) this button tag must be unique for each button in the Galactic Conquest screen
local gcTag = "Hunting"

-- 4) this is the string your Galactic Conquest button will use
--	if the game cannot find the a localization version of the string, 
--	it will directly display the text on the button
local gcString = "The Hunting Tournament" --"mods.custom_gc.tht.name"

-- 5) load any other scripts from your custom_gc_1.lvl
ScriptCB_DoFile("ifs_freeform_init_zer")
ScriptCB_DoFile("ifs_freeform_start_zer")

-- 6) this is your script that starts your Galactic Conquest game
local start_gc = ifs_freeform_start_zer

-- 7) read in any strings you need
--ReadDataFile("..\\..\\addon\\XXX\\core.lvl")

-------------------------------------------------------------------------------
-- The end of the 7 step section
-------------------------------------------------------------------------------

--add a button to the shell for our custom Galactic Conquest
if custom_GetGCButtonList then
	print("custom_gc_1: Taking control of custom_GetGCButtonList()...")
	
	--check for possible loading errors
	if cgc1_custom_GetGCButtonList then
		print("custom_gc_1: Warning: Someone else is using our cgc1_custom_GetGCButtonList variable!")
		print("custom_gc_1: Exited")
		return
	end
	
	--backup the current custom_GetGCButtonList function
	cgc1_custom_GetGCButtonList = custom_GetGCButtonList

	--this is our new custom_GetGCButtonList function
	custom_GetGCButtonList = function()
	    print("custom_gc_1: custom_GetGCButtonList(): Entered")
	    
	    --get the button table from the real function
	    local list = cgc1_custom_GetGCButtonList()
	    
	    --add in the button for our Galactic Conqust
	    local ourButton = { tag = gcTag, string = gcString, }
		table.insert( list, 1, ourButton )	    
	    
	    print("custom_gc_1: custom_GetGCButtonList(): Exited")
	    return list
	end
else
	print("custom_gc_1: Warning: No custom_GetGCButtonList() to take over")
	print("custom_gc_1: Exited")
	return
end

--Note: if you want your Galactic Conquest to only be visible at certain times (like when some other GC is completed), you will need to take over the ifs_sp_campaign_fnUpdateButtonVis() and/or ifs_sp_gc_fnUpdateButtonVis() functions (like you did with custom_GetGCButtonList()).  Both of these functions can be found in Common\scripts\PC\ifs_sp_campaign.lua

--listen for when our Galactic Conquest button is clicked
if custom_PressedGCButton then
	print("custom_gc_1: Taking control of custom_PressedGCButton()...")
	
	--check for possible loading errors
	if cgc1_custom_PressedGCButton then
		print("custom_gc_1: Warning: Someone else is using our cgc1_custom_PressedGCButton variable!")
		print("custom_gc_1: Exited")
		return
	end
	
	--backup the current custom_GetGCButtonList function
	cgc1_custom_PressedGCButton = custom_PressedGCButton

	--this is our new custom_GetGCButtonList function
	custom_PressedGCButton = function( tag )
	    print("custom_gc_1: custom_PressedGCButton(): Entered")
	    
	    --not our conquest, so let the game process it normally
	    if tag ~= gcTag then
		    return cgc1_custom_PressedGCButton()
	    end
	    
	    --it is our Galactic Conquest button, so get our game going
	    start_gc(ifs_freeform_main)
	    
	    print("custom_gc_1: custom_PressedGCButton(): Exited")
	    return true
	end
else
	print("custom_gc_1: Warning: No custom_PressedGCButton() to take over")
	print("custom_gc_1: Exited")
	return
end

print("custom_gc_1: Exited")

