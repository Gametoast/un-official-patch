print("user_script_1: Entered")

--attempt to take control of (or listen to the calls of) the ScriptPostLoad function
if ScriptPostLoad then
	print("user_script_1: Taking control of ScriptPostLoad()...")
	
	--check for possible loading errors
	if us1_ScriptPostLoad then
		print("user_script_1: Warning: Someone else is using our us1_ScriptPostLoad variable!")
		print("user_script_1: Exited")
		return
	end
	
	--backup the current ScriptPostLoad function
	us1_ScriptPostLoad = ScriptPostLoad

	--this is our new ScriptPostLoad function
	ScriptPostLoad = function()
	    print("user_script_1: ScriptPostLoad(): Entered")
	    
	    --only do these changes when in SP
	    --if we wanted them done in MP too, we should check to make sure that we are the server's host: ScriptCB_GetAmHost()
	    if not ScriptCB_InMultiplayer() then
		    --build the FakeConsole list
		    ff_rebuildFakeConsoleList()
		    
		    --do the FakeConsole commands we want to happen each time a new map starts (when ScriptPostLoad() is normally called)
		    ff_DoCommand( "Add JetPacks" )	--lets everyone fly
		    ff_DoCommand( "Lock Vehicles" )	--prevents everyone from entering vehicles (not good on space maps...)
		    ff_DoCommand( "Extreme Points" ) --gain lots os points for little work
		    ff_DoCommand( "Remove Award Effects" )	--no more graphical hues or annoying sounds when you get awards
	
			--give humans a health regeneration
			ff_healthRegen( 500, "humans" )
			
			--clear the FakeConsole table to save memory
			gConsoleCmdList = {}
		end

	    --make sure to forward the method call to the real ScriptPostLoad, so the game can function normally
	    us1_ScriptPostLoad()
	    print("user_script_1: ScriptPostLoad(): Exited")
	end
	
	print("user_script_1: Have control of ScriptPostLoad()")
else
	print("user_script_1: Warning: No ScriptPostLoad() to take over")
	print("user_script_1: Exited")
	return
end

print("user_script_1: Exited")